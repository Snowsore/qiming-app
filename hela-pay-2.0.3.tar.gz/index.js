function W(a, s) {
  var n = Object.keys(a);
  if (Object.getOwnPropertySymbols) {
    var o = Object.getOwnPropertySymbols(a);
    s && (o = o.filter(function(u) {
      return Object.getOwnPropertyDescriptor(a, u).enumerable;
    })), n.push.apply(n, o);
  }
  return n;
}
function E(a) {
  for (var s = 1; s < arguments.length; s++) {
    var n = arguments[s] != null ? arguments[s] : {};
    s % 2 ? W(Object(n), !0).forEach(function(o) {
      S(a, o, n[o]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(a, Object.getOwnPropertyDescriptors(n)) : W(Object(n)).forEach(function(o) {
      Object.defineProperty(a, o, Object.getOwnPropertyDescriptor(n, o));
    });
  }
  return a;
}
function S(a, s, n) {
  return s = Q(s), s in a ? Object.defineProperty(a, s, { value: n, enumerable: !0, configurable: !0, writable: !0 }) : a[s] = n, a;
}
function z(a, s) {
  if (!(a instanceof s))
    throw new TypeError("Cannot call a class as a function");
}
function H(a, s) {
  for (var n = 0; n < s.length; n++) {
    var o = s[n];
    o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(a, Q(o.key), o);
  }
}
function K(a, s, n) {
  return s && H(a.prototype, s), n && H(a, n), Object.defineProperty(a, "prototype", { writable: !1 }), a;
}
function Q(a) {
  var s = ee(a, "string");
  return F(s) == "symbol" ? s : String(s);
}
function ee(a, s) {
  if (F(a) != "object" || !a)
    return a;
  var n = a[Symbol.toPrimitive];
  if (n !== void 0) {
    var o = n.call(a, s || "default");
    if (F(o) != "object")
      return o;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (s === "string" ? String : Number)(a);
}
function te(a, s) {
  return se(a) || ne(a, s) || ie(a, s) || re();
}
function re() {
  throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function ie(a, s) {
  if (a) {
    if (typeof a == "string")
      return L(a, s);
    var n = Object.prototype.toString.call(a).slice(8, -1);
    if (n === "Object" && a.constructor && (n = a.constructor.name), n === "Map" || n === "Set")
      return Array.from(a);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))
      return L(a, s);
  }
}
function L(a, s) {
  (s == null || s > a.length) && (s = a.length);
  for (var n = 0, o = new Array(s); n < s; n++)
    o[n] = a[n];
  return o;
}
function ne(a, s) {
  var n = a == null ? null : typeof Symbol != "undefined" && a[Symbol.iterator] || a["@@iterator"];
  if (n != null) {
    var o, u, d, p, v = [], x = !0, y = !1;
    try {
      if (d = (n = n.call(a)).next, s === 0) {
        if (Object(n) !== n)
          return;
        x = !1;
      } else
        for (; !(x = (o = d.call(n)).done) && (v.push(o.value), v.length !== s); x = !0)
          ;
    } catch (P) {
      y = !0, u = P;
    } finally {
      try {
        if (!x && n.return != null && (p = n.return(), Object(p) !== p))
          return;
      } finally {
        if (y)
          throw u;
      }
    }
    return v;
  }
}
function se(a) {
  if (Array.isArray(a))
    return a;
}
function F(a) {
  "@babel/helpers - typeof";
  return F = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(s) {
    return typeof s;
  } : function(s) {
    return s && typeof Symbol == "function" && s.constructor === Symbol && s !== Symbol.prototype ? "symbol" : typeof s;
  }, F(a);
}
var ae = typeof globalThis != "undefined" ? globalThis : typeof window != "undefined" ? window : typeof global != "undefined" ? global : typeof self != "undefined" ? self : {};
function oe(a) {
  if (a.__esModule)
    return a;
  var s = a.default;
  if (typeof s == "function") {
    var n = function o() {
      return this instanceof o ? Reflect.construct(s, arguments, this.constructor) : s.apply(this, arguments);
    };
    n.prototype = s.prototype;
  } else
    n = {};
  return Object.defineProperty(n, "__esModule", {
    value: !0
  }), Object.keys(a).forEach(function(o) {
    var u = Object.getOwnPropertyDescriptor(a, o);
    Object.defineProperty(n, o, u.get ? u : {
      enumerable: !0,
      get: function() {
        return a[o];
      }
    });
  }), n;
}
var X = {
  exports: {}
}, ue = {}, fe = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: ue
}, Symbol.toStringTag, {
  value: "Module"
})), V = /* @__PURE__ */ oe(fe);
/**
 * [js-md5]{@link https://github.com/emn178/js-md5}
 *
 * @namespace md5
 * @version 0.8.3
 * @author Chen, Yi-Cyuan [emn178@gmail.com]
 * @copyright Chen, Yi-Cyuan 2014-2023
 * @license MIT
 */
(function(a) {
  (function() {
    var s = "input is invalid type", n = "finalize already called", o = (typeof window == "undefined" ? "undefined" : F(window)) === "object", u = o ? window : {};
    u.JS_MD5_NO_WINDOW && (o = !1);
    var d = !o && (typeof self == "undefined" ? "undefined" : F(self)) === "object", p = !u.JS_MD5_NO_NODE_JS && (typeof process == "undefined" ? "undefined" : F(process)) === "object" && process.versions && process.versions.node;
    p ? u = ae : d && (u = self);
    var v = !u.JS_MD5_NO_COMMON_JS && !0 && a.exports, x = !u.JS_MD5_NO_ARRAY_BUFFER && typeof ArrayBuffer != "undefined", y = "0123456789abcdef".split(""), P = [128, 32768, 8388608, -2147483648], b = [0, 8, 16, 24], k = ["hex", "array", "digest", "buffer", "arrayBuffer", "base64"], O = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".split(""), g = [], M;
    if (x) {
      var N = new ArrayBuffer(68);
      M = new Uint8Array(N), g = new Uint32Array(N);
    }
    var q = Array.isArray;
    (u.JS_MD5_NO_NODE_JS || !q) && (q = function(r) {
      return Object.prototype.toString.call(r) === "[object Array]";
    });
    var I = ArrayBuffer.isView;
    x && (u.JS_MD5_NO_ARRAY_BUFFER_IS_VIEW || !I) && (I = function(r) {
      return F(r) === "object" && r.buffer && r.buffer.constructor === ArrayBuffer;
    });
    var T = function(r) {
      var i = F(r);
      if (i === "string")
        return [r, !0];
      if (i !== "object" || r === null)
        throw new Error(s);
      if (x && r.constructor === ArrayBuffer)
        return [new Uint8Array(r), !1];
      if (!q(r) && !I(r))
        throw new Error(s);
      return [r, !1];
    }, B = function(r) {
      return function(i) {
        return new m(!0).update(i)[r]();
      };
    }, G = function() {
      var r = B("hex");
      p && (r = $(r)), r.create = function() {
        return new m();
      }, r.update = function(c) {
        return r.create().update(c);
      };
      for (var i = 0; i < k.length; ++i) {
        var t = k[i];
        r[t] = B(t);
      }
      return r;
    }, $ = function(r) {
      var i = V, t = V.Buffer, c;
      t.from && !u.JS_MD5_NO_BUFFER_FROM ? c = t.from : c = function(l) {
        return new t(l);
      };
      var h = function(l) {
        if (typeof l == "string")
          return i.createHash("md5").update(l, "utf8").digest("hex");
        if (l == null)
          throw new Error(s);
        return l.constructor === ArrayBuffer && (l = new Uint8Array(l)), q(l) || I(l) || l.constructor === t ? i.createHash("md5").update(c(l)).digest("hex") : r(l);
      };
      return h;
    }, j = function(r) {
      return function(i, t) {
        return new R(i, !0).update(t)[r]();
      };
    }, Z = function() {
      var r = j("hex");
      r.create = function(c) {
        return new R(c);
      }, r.update = function(c, h) {
        return r.create(c).update(h);
      };
      for (var i = 0; i < k.length; ++i) {
        var t = k[i];
        r[t] = j(t);
      }
      return r;
    };
    function m(e) {
      if (e)
        g[0] = g[16] = g[1] = g[2] = g[3] = g[4] = g[5] = g[6] = g[7] = g[8] = g[9] = g[10] = g[11] = g[12] = g[13] = g[14] = g[15] = 0, this.blocks = g, this.buffer8 = M;
      else if (x) {
        var r = new ArrayBuffer(68);
        this.buffer8 = new Uint8Array(r), this.blocks = new Uint32Array(r);
      } else
        this.blocks = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
      this.h0 = this.h1 = this.h2 = this.h3 = this.start = this.bytes = this.hBytes = 0, this.finalized = this.hashed = !1, this.first = !0;
    }
    m.prototype.update = function(e) {
      if (this.finalized)
        throw new Error(n);
      var r = T(e);
      e = r[0];
      for (var i = r[1], t, c = 0, h, f = e.length, l = this.blocks, w = this.buffer8; c < f; ) {
        if (this.hashed && (this.hashed = !1, l[0] = l[16], l[16] = l[1] = l[2] = l[3] = l[4] = l[5] = l[6] = l[7] = l[8] = l[9] = l[10] = l[11] = l[12] = l[13] = l[14] = l[15] = 0), i)
          if (x)
            for (h = this.start; c < f && h < 64; ++c)
              t = e.charCodeAt(c), t < 128 ? w[h++] = t : t < 2048 ? (w[h++] = 192 | t >>> 6, w[h++] = 128 | t & 63) : t < 55296 || t >= 57344 ? (w[h++] = 224 | t >>> 12, w[h++] = 128 | t >>> 6 & 63, w[h++] = 128 | t & 63) : (t = 65536 + ((t & 1023) << 10 | e.charCodeAt(++c) & 1023), w[h++] = 240 | t >>> 18, w[h++] = 128 | t >>> 12 & 63, w[h++] = 128 | t >>> 6 & 63, w[h++] = 128 | t & 63);
          else
            for (h = this.start; c < f && h < 64; ++c)
              t = e.charCodeAt(c), t < 128 ? l[h >>> 2] |= t << b[h++ & 3] : t < 2048 ? (l[h >>> 2] |= (192 | t >>> 6) << b[h++ & 3], l[h >>> 2] |= (128 | t & 63) << b[h++ & 3]) : t < 55296 || t >= 57344 ? (l[h >>> 2] |= (224 | t >>> 12) << b[h++ & 3], l[h >>> 2] |= (128 | t >>> 6 & 63) << b[h++ & 3], l[h >>> 2] |= (128 | t & 63) << b[h++ & 3]) : (t = 65536 + ((t & 1023) << 10 | e.charCodeAt(++c) & 1023), l[h >>> 2] |= (240 | t >>> 18) << b[h++ & 3], l[h >>> 2] |= (128 | t >>> 12 & 63) << b[h++ & 3], l[h >>> 2] |= (128 | t >>> 6 & 63) << b[h++ & 3], l[h >>> 2] |= (128 | t & 63) << b[h++ & 3]);
        else if (x)
          for (h = this.start; c < f && h < 64; ++c)
            w[h++] = e[c];
        else
          for (h = this.start; c < f && h < 64; ++c)
            l[h >>> 2] |= e[c] << b[h++ & 3];
        this.lastByteIndex = h, this.bytes += h - this.start, h >= 64 ? (this.start = h - 64, this.hash(), this.hashed = !0) : this.start = h;
      }
      return this.bytes > 4294967295 && (this.hBytes += this.bytes / 4294967296 << 0, this.bytes = this.bytes % 4294967296), this;
    }, m.prototype.finalize = function() {
      if (!this.finalized) {
        this.finalized = !0;
        var e = this.blocks, r = this.lastByteIndex;
        e[r >>> 2] |= P[r & 3], r >= 56 && (this.hashed || this.hash(), e[0] = e[16], e[16] = e[1] = e[2] = e[3] = e[4] = e[5] = e[6] = e[7] = e[8] = e[9] = e[10] = e[11] = e[12] = e[13] = e[14] = e[15] = 0), e[14] = this.bytes << 3, e[15] = this.hBytes << 3 | this.bytes >>> 29, this.hash();
      }
    }, m.prototype.hash = function() {
      var e, r, i, t, c, h, f = this.blocks;
      this.first ? (e = f[0] - 680876937, e = (e << 7 | e >>> 25) - 271733879 << 0, t = (-1732584194 ^ e & 2004318071) + f[1] - 117830708, t = (t << 12 | t >>> 20) + e << 0, i = (-271733879 ^ t & (e ^ -271733879)) + f[2] - 1126478375, i = (i << 17 | i >>> 15) + t << 0, r = (e ^ i & (t ^ e)) + f[3] - 1316259209, r = (r << 22 | r >>> 10) + i << 0) : (e = this.h0, r = this.h1, i = this.h2, t = this.h3, e += (t ^ r & (i ^ t)) + f[0] - 680876936, e = (e << 7 | e >>> 25) + r << 0, t += (i ^ e & (r ^ i)) + f[1] - 389564586, t = (t << 12 | t >>> 20) + e << 0, i += (r ^ t & (e ^ r)) + f[2] + 606105819, i = (i << 17 | i >>> 15) + t << 0, r += (e ^ i & (t ^ e)) + f[3] - 1044525330, r = (r << 22 | r >>> 10) + i << 0), e += (t ^ r & (i ^ t)) + f[4] - 176418897, e = (e << 7 | e >>> 25) + r << 0, t += (i ^ e & (r ^ i)) + f[5] + 1200080426, t = (t << 12 | t >>> 20) + e << 0, i += (r ^ t & (e ^ r)) + f[6] - 1473231341, i = (i << 17 | i >>> 15) + t << 0, r += (e ^ i & (t ^ e)) + f[7] - 45705983, r = (r << 22 | r >>> 10) + i << 0, e += (t ^ r & (i ^ t)) + f[8] + 1770035416, e = (e << 7 | e >>> 25) + r << 0, t += (i ^ e & (r ^ i)) + f[9] - 1958414417, t = (t << 12 | t >>> 20) + e << 0, i += (r ^ t & (e ^ r)) + f[10] - 42063, i = (i << 17 | i >>> 15) + t << 0, r += (e ^ i & (t ^ e)) + f[11] - 1990404162, r = (r << 22 | r >>> 10) + i << 0, e += (t ^ r & (i ^ t)) + f[12] + 1804603682, e = (e << 7 | e >>> 25) + r << 0, t += (i ^ e & (r ^ i)) + f[13] - 40341101, t = (t << 12 | t >>> 20) + e << 0, i += (r ^ t & (e ^ r)) + f[14] - 1502002290, i = (i << 17 | i >>> 15) + t << 0, r += (e ^ i & (t ^ e)) + f[15] + 1236535329, r = (r << 22 | r >>> 10) + i << 0, e += (i ^ t & (r ^ i)) + f[1] - 165796510, e = (e << 5 | e >>> 27) + r << 0, t += (r ^ i & (e ^ r)) + f[6] - 1069501632, t = (t << 9 | t >>> 23) + e << 0, i += (e ^ r & (t ^ e)) + f[11] + 643717713, i = (i << 14 | i >>> 18) + t << 0, r += (t ^ e & (i ^ t)) + f[0] - 373897302, r = (r << 20 | r >>> 12) + i << 0, e += (i ^ t & (r ^ i)) + f[5] - 701558691, e = (e << 5 | e >>> 27) + r << 0, t += (r ^ i & (e ^ r)) + f[10] + 38016083, t = (t << 9 | t >>> 23) + e << 0, i += (e ^ r & (t ^ e)) + f[15] - 660478335, i = (i << 14 | i >>> 18) + t << 0, r += (t ^ e & (i ^ t)) + f[4] - 405537848, r = (r << 20 | r >>> 12) + i << 0, e += (i ^ t & (r ^ i)) + f[9] + 568446438, e = (e << 5 | e >>> 27) + r << 0, t += (r ^ i & (e ^ r)) + f[14] - 1019803690, t = (t << 9 | t >>> 23) + e << 0, i += (e ^ r & (t ^ e)) + f[3] - 187363961, i = (i << 14 | i >>> 18) + t << 0, r += (t ^ e & (i ^ t)) + f[8] + 1163531501, r = (r << 20 | r >>> 12) + i << 0, e += (i ^ t & (r ^ i)) + f[13] - 1444681467, e = (e << 5 | e >>> 27) + r << 0, t += (r ^ i & (e ^ r)) + f[2] - 51403784, t = (t << 9 | t >>> 23) + e << 0, i += (e ^ r & (t ^ e)) + f[7] + 1735328473, i = (i << 14 | i >>> 18) + t << 0, r += (t ^ e & (i ^ t)) + f[12] - 1926607734, r = (r << 20 | r >>> 12) + i << 0, c = r ^ i, e += (c ^ t) + f[5] - 378558, e = (e << 4 | e >>> 28) + r << 0, t += (c ^ e) + f[8] - 2022574463, t = (t << 11 | t >>> 21) + e << 0, h = t ^ e, i += (h ^ r) + f[11] + 1839030562, i = (i << 16 | i >>> 16) + t << 0, r += (h ^ i) + f[14] - 35309556, r = (r << 23 | r >>> 9) + i << 0, c = r ^ i, e += (c ^ t) + f[1] - 1530992060, e = (e << 4 | e >>> 28) + r << 0, t += (c ^ e) + f[4] + 1272893353, t = (t << 11 | t >>> 21) + e << 0, h = t ^ e, i += (h ^ r) + f[7] - 155497632, i = (i << 16 | i >>> 16) + t << 0, r += (h ^ i) + f[10] - 1094730640, r = (r << 23 | r >>> 9) + i << 0, c = r ^ i, e += (c ^ t) + f[13] + 681279174, e = (e << 4 | e >>> 28) + r << 0, t += (c ^ e) + f[0] - 358537222, t = (t << 11 | t >>> 21) + e << 0, h = t ^ e, i += (h ^ r) + f[3] - 722521979, i = (i << 16 | i >>> 16) + t << 0, r += (h ^ i) + f[6] + 76029189, r = (r << 23 | r >>> 9) + i << 0, c = r ^ i, e += (c ^ t) + f[9] - 640364487, e = (e << 4 | e >>> 28) + r << 0, t += (c ^ e) + f[12] - 421815835, t = (t << 11 | t >>> 21) + e << 0, h = t ^ e, i += (h ^ r) + f[15] + 530742520, i = (i << 16 | i >>> 16) + t << 0, r += (h ^ i) + f[2] - 995338651, r = (r << 23 | r >>> 9) + i << 0, e += (i ^ (r | ~t)) + f[0] - 198630844, e = (e << 6 | e >>> 26) + r << 0, t += (r ^ (e | ~i)) + f[7] + 1126891415, t = (t << 10 | t >>> 22) + e << 0, i += (e ^ (t | ~r)) + f[14] - 1416354905, i = (i << 15 | i >>> 17) + t << 0, r += (t ^ (i | ~e)) + f[5] - 57434055, r = (r << 21 | r >>> 11) + i << 0, e += (i ^ (r | ~t)) + f[12] + 1700485571, e = (e << 6 | e >>> 26) + r << 0, t += (r ^ (e | ~i)) + f[3] - 1894986606, t = (t << 10 | t >>> 22) + e << 0, i += (e ^ (t | ~r)) + f[10] - 1051523, i = (i << 15 | i >>> 17) + t << 0, r += (t ^ (i | ~e)) + f[1] - 2054922799, r = (r << 21 | r >>> 11) + i << 0, e += (i ^ (r | ~t)) + f[8] + 1873313359, e = (e << 6 | e >>> 26) + r << 0, t += (r ^ (e | ~i)) + f[15] - 30611744, t = (t << 10 | t >>> 22) + e << 0, i += (e ^ (t | ~r)) + f[6] - 1560198380, i = (i << 15 | i >>> 17) + t << 0, r += (t ^ (i | ~e)) + f[13] + 1309151649, r = (r << 21 | r >>> 11) + i << 0, e += (i ^ (r | ~t)) + f[4] - 145523070, e = (e << 6 | e >>> 26) + r << 0, t += (r ^ (e | ~i)) + f[11] - 1120210379, t = (t << 10 | t >>> 22) + e << 0, i += (e ^ (t | ~r)) + f[2] + 718787259, i = (i << 15 | i >>> 17) + t << 0, r += (t ^ (i | ~e)) + f[9] - 343485551, r = (r << 21 | r >>> 11) + i << 0, this.first ? (this.h0 = e + 1732584193 << 0, this.h1 = r - 271733879 << 0, this.h2 = i - 1732584194 << 0, this.h3 = t + 271733878 << 0, this.first = !1) : (this.h0 = this.h0 + e << 0, this.h1 = this.h1 + r << 0, this.h2 = this.h2 + i << 0, this.h3 = this.h3 + t << 0);
    }, m.prototype.hex = function() {
      this.finalize();
      var e = this.h0, r = this.h1, i = this.h2, t = this.h3;
      return y[e >>> 4 & 15] + y[e & 15] + y[e >>> 12 & 15] + y[e >>> 8 & 15] + y[e >>> 20 & 15] + y[e >>> 16 & 15] + y[e >>> 28 & 15] + y[e >>> 24 & 15] + y[r >>> 4 & 15] + y[r & 15] + y[r >>> 12 & 15] + y[r >>> 8 & 15] + y[r >>> 20 & 15] + y[r >>> 16 & 15] + y[r >>> 28 & 15] + y[r >>> 24 & 15] + y[i >>> 4 & 15] + y[i & 15] + y[i >>> 12 & 15] + y[i >>> 8 & 15] + y[i >>> 20 & 15] + y[i >>> 16 & 15] + y[i >>> 28 & 15] + y[i >>> 24 & 15] + y[t >>> 4 & 15] + y[t & 15] + y[t >>> 12 & 15] + y[t >>> 8 & 15] + y[t >>> 20 & 15] + y[t >>> 16 & 15] + y[t >>> 28 & 15] + y[t >>> 24 & 15];
    }, m.prototype.toString = m.prototype.hex, m.prototype.digest = function() {
      this.finalize();
      var e = this.h0, r = this.h1, i = this.h2, t = this.h3;
      return [e & 255, e >>> 8 & 255, e >>> 16 & 255, e >>> 24 & 255, r & 255, r >>> 8 & 255, r >>> 16 & 255, r >>> 24 & 255, i & 255, i >>> 8 & 255, i >>> 16 & 255, i >>> 24 & 255, t & 255, t >>> 8 & 255, t >>> 16 & 255, t >>> 24 & 255];
    }, m.prototype.array = m.prototype.digest, m.prototype.arrayBuffer = function() {
      this.finalize();
      var e = new ArrayBuffer(16), r = new Uint32Array(e);
      return r[0] = this.h0, r[1] = this.h1, r[2] = this.h2, r[3] = this.h3, e;
    }, m.prototype.buffer = m.prototype.arrayBuffer, m.prototype.base64 = function() {
      for (var e, r, i, t = "", c = this.array(), h = 0; h < 15; )
        e = c[h++], r = c[h++], i = c[h++], t += O[e >>> 2] + O[(e << 4 | r >>> 4) & 63] + O[(r << 2 | i >>> 6) & 63] + O[i & 63];
      return e = c[h], t += O[e >>> 2] + O[e << 4 & 63] + "==", t;
    };
    function R(e, r) {
      var i, t = T(e);
      if (e = t[0], t[1]) {
        var c = [], h = e.length, f = 0, l;
        for (i = 0; i < h; ++i)
          l = e.charCodeAt(i), l < 128 ? c[f++] = l : l < 2048 ? (c[f++] = 192 | l >>> 6, c[f++] = 128 | l & 63) : l < 55296 || l >= 57344 ? (c[f++] = 224 | l >>> 12, c[f++] = 128 | l >>> 6 & 63, c[f++] = 128 | l & 63) : (l = 65536 + ((l & 1023) << 10 | e.charCodeAt(++i) & 1023), c[f++] = 240 | l >>> 18, c[f++] = 128 | l >>> 12 & 63, c[f++] = 128 | l >>> 6 & 63, c[f++] = 128 | l & 63);
        e = c;
      }
      e.length > 64 && (e = new m(!0).update(e).array());
      var w = [], D = [];
      for (i = 0; i < 64; ++i) {
        var U = e[i] || 0;
        w[i] = 92 ^ U, D[i] = 54 ^ U;
      }
      m.call(this, r), this.update(D), this.oKeyPad = w, this.inner = !0, this.sharedMemory = r;
    }
    R.prototype = new m(), R.prototype.finalize = function() {
      if (m.prototype.finalize.call(this), this.inner) {
        this.inner = !1;
        var e = this.array();
        m.call(this, this.sharedMemory), this.update(this.oKeyPad), this.update(e), m.prototype.finalize.call(this);
      }
    };
    var A = G();
    A.md5 = A, A.md5.hmac = Z(), v ? a.exports = A : u.md5 = A;
  })();
})(X);
var he = X.exports, le = "2.0.3";
function Y(a, s) {
  var n = "", o = "";
  for (var u in s)
    n += u + "=" + encodeURIComponent(s[u]) + "&";
  if (n = n.replace(/&$/, ""), a.includes("#/")) {
    var d = a.split("#/")[1];
    if (!d.includes("?"))
      return a + "?" + n;
    var p = (d + "&" + n).split("?")[0], v = (d + "&" + n).split("?")[1].split("&"), x = v.reduce(function(y, P) {
      var b = P.split("=");
      return y[b[0]] = P.slice(b[0].length + 1), y;
    }, {});
    return a.split("#/")[0] + "#/" + Y(p, x);
  }
  return /\?$/.test(a) ? o = a + n : o = a.replace(/\/?$/, "?") + n, o;
}
function ce(a) {
  var s = Object.prototype.toString, n = {
    "[object Boolean]": "boolean",
    "[object Number]": "number",
    "[object String]": "string",
    "[object Function]": "function",
    "[object Array]": "array",
    "[object Date]": "date",
    "[object RegExp]": "regExp",
    "[object Undefined]": "undefined",
    "[object Null]": "null",
    "[object Object]": "object"
  };
  return n[s.call(a)];
}
var C = function a(s) {
  var n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1, o = ce(s), u;
  if (o === "array")
    u = [];
  else if (o === "object")
    u = {};
  else
    return s;
  for (var d = 0, p = Object.entries(s); d < p.length; d++) {
    var v = te(p[d], 2), x = v[0], y = v[1];
    n && (y === "" || y === null || y === void 0) || (u[x] = a(y));
  }
  return u;
}, de = function() {
  var s = {
    Chrome: /Chrome/,
    IE: /MSIE/,
    Firefox: /Firefox/,
    Opera: /Presto/,
    Safari: /Version\/([\d.]+).*Safari/,
    360: /360SE/,
    QQBrowswe: /QQ/,
    Edge: /Edg/
  }, n = {
    iPhone: /iPhone/,
    iPad: /iPad/,
    Android: /Android/,
    Windows: /Windows/,
    Mac: /Macintosh/
  }, o = navigator.userAgent, u = {
    browserName: "",
    // 浏览器名称
    browserVersion: "",
    // 浏览器版本
    osName: "",
    // 操作系统名称
    osVersion: "",
    // 操作系统版本
    deviceName: "",
    // 设备名称
    dpi: 96,
    lang: navigator.language
  };
  try {
    for (var d in s)
      s[d].test(o) && (u.browserName = d, d === "Chrome" ? u.browserVersion = o.split("Chrome/")[1].split(" ")[0] : d === "IE" ? u.browserVersion = o.split("MSIE ")[1].split(" ")[1] : d === "Firefox" ? u.browserVersion = o.split("Firefox/")[1] : d === "Opera" ? u.browserVersion = o.split("Version/")[1] : d === "Safari" ? u.browserVersion = o.split("Version/")[1].split(" ")[0] : d === "360" ? u.browserVersion = "" : d === "QQBrowswe" ? u.browserVersion = o.split("Version/")[1].split(" ")[0] : d === "Edge" && (u.browserVersion = o.split("Edg/")[1].split(" ")[0]));
    for (var p in n)
      n[p].test(o) && (u.osName = p, p === "Windows" ? u.osVersion = o.split("Windows NT ")[1].split(";")[0] : p === "Mac" ? u.osVersion = o.split("Mac OS X ")[1].split(")")[0] : p === "iPhone" ? u.osVersion = o.split("iPhone OS ")[1].split(" ")[0] : p === "iPad" ? u.osVersion = o.split("iPad; CPU OS ")[1].split(" ")[0] : p === "Android" && (u.osVersion = o.split("Android ")[1].split(";")[0], u.deviceName = o.split("(Linux; Android ")[1].split("; ")[1].split(" Build")[0]));
    u.dpi = u.dpi * window.devicePixelRatio;
  } catch (v) {
    console.log(v);
  }
  return u;
}, pe = function(s) {
  var n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "__uuid__";
  if (!s && n) {
    var o = window.localStorage.getItem(n);
    if (o)
      return o;
  }
  var u = (/* @__PURE__ */ new Date()).getTime(), d = "xxxxxxxxxxxxxxxxyxxxxxxxxxxxxxxx".replace(/[xy]/g, function(p) {
    var v = (u + Math.random() * 16) % 16 | 0;
    return u = Math.floor(u / 16), (p == "x" ? v : v & 3 | 8).toString(16);
  });
  return n && window.localStorage.setItem(n, d), d;
}, ve = /* @__PURE__ */ function() {
  function a() {
    z(this, a);
  }
  return K(a, [{
    key: "request",
    value: function(n, o, u) {
      var d = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : "GET";
      return new Promise(function(p) {
        var v;
        try {
          v = new XMLHttpRequest();
        } catch (P) {
          v = new ActiveXObject("Microsoft.XMLHTTP");
        }
        var x = u && u.params || {};
        if (v.open(d, Y(n, x), !0), v.setRequestHeader("Content-Type", "application/json"), u && u.headers)
          for (var y in u.headers)
            v.setRequestHeader(y, u.headers[y]);
        v.onreadystatechange = function() {
          if (v.readyState === 4) {
            var P = v.responseText;
            try {
              P = JSON.parse(v.responseText);
            } catch (b) {
            }
            p(P || {});
          }
        }, v.send(JSON.stringify(o));
      });
    }
  }, {
    key: "get",
    value: function(n) {
      var o = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
      return this.request(n, {}, o, "GET");
    }
  }, {
    key: "post",
    value: function(n) {
      var o = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, u = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
      return this.request(n, o, u, "POST");
    }
  }]), a;
}(), ye = function() {
  try {
    var s = new ve(), n = s.request.bind(s);
    return n.get = s.get.bind(s), n.post = s.post.bind(s), n;
  } catch (o) {
    return console.log(o), function() {
      return Promise.resolve(arguments.length <= 0 ? void 0 : arguments[0]);
    };
  }
}, _ = ye(), J = function(s) {
  return s.split(".").join("0");
}, xe = /* @__PURE__ */ function() {
  function a(s) {
    z(this, a), S(this, "SALT", "3582d6815e095be3d83fecae039ef46e88cff3844bba6c5f703dae669a9a6647"), S(this, "baseURL", "https://mv-ps.xdplt.com/api/v1"), S(this, "clientType", void 0), S(this, "thirdPlatformCode", ""), S(this, "pkg", ""), S(this, "openId", ""), S(this, "wxOpenId", ""), S(this, "versionName", "1.0.1"), S(this, "versionCode", J(this.versionName)), s && this.setParams(s), this.setParams = this.setParams.bind(this), this.ktk = this.ktk.bind(this), this.uuid = this.uuid.bind(this), this.wxJSPay = this.wxJSPay.bind(this), this.getHelaPayParams = this.getHelaPayParams.bind(this), this.requestAnonymousLogin = this.requestAnonymousLogin.bind(this), this.requestUserInfo = this.requestUserInfo.bind(this), this.requestAllSkuList = this.requestAllSkuList.bind(this), this.requestCreateOrder = this.requestCreateOrder.bind(this), this.requestPayScan = this.requestPayScan.bind(this), this.requestWakeWeChatPay = this.requestWakeWeChatPay.bind(this), this.requestPayResult = this.requestPayResult.bind(this);
  }
  return K(a, [{
    key: "setParams",
    value: function(n) {
      n && n.code && (this.thirdPlatformCode = n.code);
      try {
        var o = window.navigator.userAgent.toLowerCase();
        o.indexOf("micromessenger") !== -1 && (this.clientType = 0);
      } catch (u) {
      }
      return n && n.version && (this.versionName = n.version, this.versionCode = J(this.versionName)), n && n.pkg && (this.pkg = n.pkg), n && n.tk && (this.openId = n.tk, window.localStorage.setItem(this.ktk(this.pkg), this.openId)), this.openId = this.openId || this.uuid(this.pkg), this.requestAnonymousLogin();
    }
  }, {
    key: "ktk",
    value: function(n) {
      return "__".concat(n || "hela_pay", "__");
    }
  }, {
    key: "uuid",
    value: function(n) {
      return pe(!1, this.ktk(n));
    }
  }, {
    key: "wxJSPay",
    value: function(n, o) {
      function u() {
        WeixinJSBridge.invoke("getBrandWCPayRequest", {
          appId: n.appId,
          // 公众号名称，由商户传入
          timeStamp: n.timeStamp,
          // 时间戳，自1970年以来的秒数
          nonceStr: n.nonceStr,
          // 随机串
          package: "prepay_id=".concat(n.prepayId),
          signType: "MD5",
          // 微信签名方式：
          paySign: n.sign
          // 微信签名
        }, function(d) {
          d.err_msg == "get_brand_wcpay_request:ok" && o && o();
        });
      }
      typeof WeixinJSBridge == "undefined" ? document.addEventListener ? document.addEventListener("WeixinJSBridgeReady", u, !1) : document.attachEvent && (document.attachEvent("WeixinJSBridgeReady", u), document.attachEvent("onWeixinJSBridgeReady", u)) : u();
    }
  }, {
    key: "getHelaPayParams",
    value: function() {
      var n = de(), o = Date.now(), u = he.md5(this.openId + this.pkg + this.versionName + n.lang + o + this.SALT), d = n.osName || n.browserName, p = n.osVersion || n.browserVersion;
      return C({
        h: window.screen.height,
        w: window.screen.width,
        model: p,
        vendor: p,
        sdk: d,
        sdkvn: le,
        pkg: this.pkg,
        thirdPlatformCode: this.thirdPlatformCode,
        v: this.versionCode,
        vn: this.versionName,
        tk: this.openId,
        lang: n.lang,
        os: n.osName,
        locale: n.lang,
        ts: o,
        vc: u,
        anid: this.openId,
        oaid: this.openId,
        brand: d,
        channel: "web"
      }, !0);
    }
  }, {
    key: "requestAnonymousLogin",
    value: function() {
      var n = this.getHelaPayParams();
      return !n || !n.pkg ? Promise.reject({
        message: {
          code: "F40002",
          messageInfo: "包名 pkg 不存在，初始化参数 pkg 必传"
        }
      }) : _.post("".concat(this.baseURL, "/user/login"), C({
        pkg: n.pkg,
        tk: n.tk,
        anid: n.anid,
        os: n.os,
        thirdPlatformCode: n.thirdPlatformCode,
        type: this.clientType
      }, !0), {
        params: C(E(E({}, n), {}, {
          type: this.clientType
        }), !0)
      });
    }
  }, {
    key: "requestUserInfo",
    value: function() {
      var n = this;
      return new Promise(function(o, u) {
        var d = n.getHelaPayParams();
        if (!d || !d.pkg) {
          u({
            message: {
              code: "F40004",
              messageInfo: "包名 pkg 不存在，请在 sdk 初始化后进行 request 请求"
            }
          });
          return;
        }
        _.get("".concat(n.baseURL, "/user/info"), {
          params: d
        }).then(function(p) {
          p && p.result ? (n.wxOpenId = p.result.openId, o(p.result)) : u(p);
        }).catch(function(p) {
          return u(p);
        });
      });
    }
  }, {
    key: "requestAllSkuList",
    value: function() {
      var n = this, o = this.getHelaPayParams();
      return new Promise(function(u, d) {
        if (!o || !o.pkg) {
          d({
            message: {
              code: "F40004",
              messageInfo: "包名 pkg 不存在，请在 sdk 初始化后进行 request 请求"
            }
          });
          return;
        }
        _.get("".concat(n.baseURL, "/sku/skuAll"), {
          params: o
        }).then(function(p) {
          p && p.result && p.result.length ? u(p.result) : d(p);
        }).catch(function(p) {
          d(p);
        });
      });
    }
  }, {
    key: "requestCreateOrder",
    value: function(n, o) {
      var u = this, d = this.getHelaPayParams();
      return new Promise(function(p, v) {
        if (!n) {
          v({
            message: {
              code: "F40003",
              messageInfo: "skuId 必传"
            }
          });
          return;
        }
        if (!d || !d.pkg) {
          v({
            message: {
              code: "F40004",
              messageInfo: "包名 pkg 不存在，请在 sdk 初始化后进行 request 请求"
            }
          });
          return;
        }
        _.post("".concat(u.baseURL, "/sku/payment/pay"), C({
          skuId: n,
          payType: o,
          miniOpenId: u.wxOpenId
        }, !0), {
          params: d
        }).then(function(x) {
          x && x.result && x.result.payOrderId ? p(E(E({}, x.result), {}, {
            timeStamp: x.result.timeStamp || Date.now() / 1e3 + "",
            signType: x.result.signType || "MD5"
          })) : v(x);
        }).catch(function(x) {
          v(x);
        });
      });
    }
  }, {
    key: "requestPayScan",
    value: function(n) {
      return this.requestCreateOrder(n, 3);
    }
  }, {
    key: "requestWakeWeChatPay",
    value: function(n, o) {
      var u = this;
      return new Promise(function(d, p) {
        if (u.clientType === 0 && !u.wxOpenId) {
          u.requestUserInfo().finally(function() {
            u.requestCreateOrder(n, o || u.clientType === 0 ? 0 : 2).then(function(v) {
              return d(v);
            }).catch(function(v) {
              return p(v);
            });
          });
          return;
        }
        u.requestCreateOrder(n, o || u.clientType === 0 ? 0 : 2).then(function(v) {
          return d(v);
        }).catch(function(v) {
          return p(v);
        });
      });
    }
  }, {
    key: "requestPayResult",
    value: function(n) {
      var o = this, u = this.getHelaPayParams();
      return new Promise(function(d, p) {
        if (!u || !u.pkg) {
          p({
            message: {
              code: "F40004",
              messageInfo: "包名 pkg 不存在，请在 sdk 初始化后进行 request 请求"
            }
          });
          return;
        }
        _.get("".concat(o.baseURL, "/sku/payment/").concat(n), {
          params: u
        }).then(function(v) {
          v && v.result && v.result.status ? d(v.result.status === 1) : p(v);
        }).catch(function(v) {
          p(v);
        });
      });
    }
  }]), a;
}(), me = function(s) {
  try {
    var n = new xe(s);
    return {
      init: n.setParams.bind(n),
      uuid: n.uuid.bind(n),
      wxJSPay: n.wxJSPay.bind(n),
      requestUserInfo: n.requestUserInfo.bind(n),
      requestAllSkuList: n.requestAllSkuList.bind(n),
      requestPayScan: n.requestPayScan.bind(n),
      requestWakeWeChatPay: n.requestWakeWeChatPay.bind(n),
      requestPayResult: n.requestPayResult.bind(n)
    };
  } catch (o) {
    return console.log(o), {};
  }
};
export {
  me as default
};
